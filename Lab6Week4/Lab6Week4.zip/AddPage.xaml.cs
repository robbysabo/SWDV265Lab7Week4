namespace Lab6Week4;

public partial class AddPage : ContentPage
{
	public AddPage()
	{
		InitializeComponent();
	}
}